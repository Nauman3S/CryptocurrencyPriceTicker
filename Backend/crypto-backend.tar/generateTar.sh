rm -rf crypto-backend.tar
tar -cvf crypto-backend.tar *
